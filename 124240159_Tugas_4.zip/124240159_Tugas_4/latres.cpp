#include <iostream>
#include <string>
using namespace std;

struct Buku {
    string judul, pengarang;
    int tahun;
};

struct Node {
    Buku data;
    Node* left;
    Node* right;
};

struct StackNode {
    string action; 
    Buku data;
    StackNode* next;
};

Node* root = nullptr;
StackNode* topStack = nullptr;

// PTB
Node* createNode(Buku b) {
    Node* newNode = new Node;
    newNode->data = b;
    newNode->left = newNode->right = nullptr;
    return newNode;
}

Node* insert(Node* node, Buku b) {
    if (!node) return createNode(b);

    if (b.judul < node->data.judul)
        node->left = insert(node->left, b);
    else if (b.judul > node->data.judul)
        node->right = insert(node->right, b);
    return node;
}

void inorder(Node* node) {
    if (!node) return;
    inorder(node->left);
    cout << "Judul: " << node->data.judul << "\nPengarang: " << node->data.pengarang << "\nTahun: " << node->data.tahun << "\n";
    inorder(node->right);
}

Node* findMin(Node* node) {
    while (node->left)
        node = node->left;
    return node;
}

Node* deleteNode(Node* node, string judul, Buku& deletedData, bool& found) {
    if (!node) return nullptr;
    if (judul < node->data.judul)
        node->left = deleteNode(node->left, judul, deletedData, found);
    else if (judul > node->data.judul)
        node->right = deleteNode(node->right, judul, deletedData, found);
    else {
        found = true;
        deletedData = node->data;

        if (!node->left) {
            Node* temp = node->right;
            delete node;
            return temp;
        } else if (!node->right) {
            Node* temp = node->left;
            delete node;
            return temp;
        } else {
            Node* temp = findMin(node->right);
            node->data = temp->data;
            node->right = deleteNode(node->right, temp->data.judul, deletedData, found);
        }
    }
    return node;
}

void push(string action, Buku b) {
    StackNode* newNode = new StackNode;
    newNode->action = action;
    newNode->data = b;
    newNode->next = topStack;
    topStack = newNode;
}

bool pop(string& action, Buku& b) {
    if (!topStack) return false;
    action = topStack->action;
    b = topStack->data;
    StackNode* temp = topStack;
    topStack = topStack->next;
    delete temp;
    return true;
}

void menu() {
    int pilihan;
    do {
        cout << " MENU \n";
        cout << "1. tambah buku\n";
        cout << "2. tampilkan buku\n";
        cout << "3. hapus buku\n";
        cout << "4. undo tindakan\n";
        cout << "5. keluar\n";
        cout << "pilihan: ";
        cin >> pilihan;
        cin.ignore();

        if (pilihan == 1) {
            Buku b;
            cout << "judul: "; getline(cin, b.judul);
            cout << "pengarang: "; getline(cin, b.pengarang);
            cout << "tahun Terbit: "; cin >> b.tahun; cin.ignore();
            root = insert(root, b);
            push("tambah", b);
            cout << "buku berhasil ditambahkan.\n";

        } else if (pilihan == 2) {
            cout << "Daftar Buku\n";
            inorder(root);

        } else if (pilihan == 3) {
            string judul;
            cout << "masukkan buku yang ingin dihapus: ";
            getline(cin, judul);
            Buku deleted;
            bool found = false;
            root = deleteNode(root, judul, deleted, found);
            if (found) {
                push("hapus", deleted);
                cout << "buku berhasil dihapus.\n";
            } else {
                cout << "maaf, buku tidak ditemukan.\n";
            }

        } else if (pilihan == 4) {
            string action;
            Buku b;
            if (pop(action, b)) {
                if (action == "tambah") {
                    bool dummy;
                    root = deleteNode(root, b.judul, b, dummy);
                    cout << "undo: buku yang ditambahkan telah dihapus.\n";
                } else if (action == "hapus") {
                    root = insert(root, b);
                    cout << "undo: buku yang dihapus telah dikembalikan.\n";
                }
            } else {
                cout << "tidak ada tindakan untuk di undo.\n";
            }

        } else if (pilihan == 5) {
            cout << "terima kasih!\n";
        } else {
            cout << "pilihan tidak valid.\n";
        }
    } while (pilihan != 5);
}

int main() {
    menu();
    return 0;
}
